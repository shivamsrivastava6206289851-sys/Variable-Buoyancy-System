clc;
clear;
close all;

%% 1. VBS PARAMETERS
rho = 1000;                 % Water density (kg/m^3)
g = 9.81;                   % Gravitational acceleration (m/s^2)

md = 1.189;                 % Dry mass (kg)
Bmax = 15.06;               % Estimated maximum buoyancy (N)
Vdisp = Bmax/(rho*g);       % Displaced volume (m^3)

N_tanks = 2;
Vtank = 250e-6;             % Capacity per tank (m^3) = 250 mL
Vmax = N_tanks*Vtank;       % Total capacity = 500 mL

% Pump stop volume per tank (m^3).
% Vtank -> pumps run until tanks are full (original behaviour).
% Use e.g. 0.8*Vtank to stop pumps early and keep vent torque low.
Vstop = Vtank;

%% 2. DRAG PARAMETERS
CD = 0.25;                  % Axial drag coefficient
D = 0.10;                   % Vehicle diameter (m)
A = pi*D^2/4;               % Frontal area (m^2)

%% 3. PUMP FLOW RATES
flow_Lmin = [0.45 0.90 1.35 1.80];     % Flow rate of EACH pump (L/min)
Qpump = flow_Lmin*1e-3/60;             % m^3/s

%% 4. SIMULATION SETTINGS
dt = 0.01;
tEnd = 40;
t = 0:dt:tEnd;
N = length(t);
nCases = length(Qpump);

Z_all = zeros(nCases,N);
V1_all = zeros(nCases,N);
V2_all = zeros(nCases,N);
Vtotal_all = zeros(nCases,N);
Mass_all = zeros(nCases,N);
Weight_all = zeros(nCases,N);
Velocity_all = zeros(nCases,N);

%% 5. SIMULATION FOR EACH PUMP FLOW RATE
for k = 1:nCases

    z = zeros(1,N);
    v = zeros(1,N);

    % Water volume in each tank (both pumps identical)
    V1 = min(Qpump(k)*t, Vstop);
    V2 = V1;
    Vtotal = V1 + V2;
    mass = md + rho*Vtotal;
    weight = mass*g;

    for n = 1:N-1

        % Buoyancy (partial-submergence approximation)
        if weight(n) < Bmax
            B = weight(n);
        else
            B = Bmax;
        end

        % Drag (positive velocity = downward)
        Fdrag = 0.5*rho*CD*A*abs(v(n))*v(n);

        % m*a = Weight - Buoyancy - Drag
        a = (weight(n) - B - Fdrag)/mass(n);

        v(n+1) = v(n) + a*dt;
        z(n+1) = z(n) + v(n+1)*dt;

        % Surface limit
        if z(n+1) < 0
            z(n+1) = 0;
            if v(n+1) < 0
                v(n+1) = 0;
            end
        end
    end

    Z_all(k,:) = z;
    V1_all(k,:) = V1;
    V2_all(k,:) = V2;
    Vtotal_all(k,:) = Vtotal;
    Mass_all(k,:) = mass;
    Weight_all(k,:) = weight;
    Velocity_all(k,:) = v;
end

%% 6. VBS SUMMARY
mFull = md + rho*Vmax;
fprintf('\n===== TWO-TANK VBS RESULTS =====\n');
fprintf('Dry mass                  = %.3f kg\n',md);
fprintf('Dry weight                = %.2f N\n',md*g);
fprintf('Maximum buoyancy          = %.2f N\n',Bmax);
fprintf('Estimated displaced volume= %.3f L\n',Vdisp*1000);
fprintf('Fully ballasted mass      = %.3f kg\n',mFull);
fprintf('Fully ballasted weight    = %.2f N\n',mFull*g);
fprintf('Net force at full ballast = %.2f N downward\n',mFull*g - Bmax);
Vneutral = (Bmax/g - md)/rho;
fprintf('Neutral ballast estimate  = %.1f mL total (%.1f mL per tank)\n', ...
    Vneutral*1e6, Vneutral*1e6/N_tanks);

%% 7. VENT VALVE ACTUATION FORCE & MG90S TORQUE
% Each depth Zq is treated as the maximum operating depth:
%   Pz   = Patm + rho*g*Zq
%   Pg,0 = sigma*(Patm + rho*g*Zq)
%   Pg   = Pg,0*Vt/(Vt - Vw)      (Vw = water per tank when depth Zq is reached)
%   F    = (Pg - Pz)*Avent*eta
%   T    = F*arm
sigma = 1.1;                 % precharge factor
eta   = 0.4;                 % vent valve efficiency
dVent = 4e-3;                % vent diameter (m)
Avent = pi*dVent^2/4;        % vent area (m^2)
arm   = 0.015;               % torque arm (m)
Tmin  = 0.176;               % MG90S torque range (N*m)
Tmax  = 0.216;
Patm  = 101325;              % Pa

flow_sel = 0.90;             % L/min per pump
k = find(abs(flow_Lmin - flow_sel) < 1e-6);
Zs = Z_all(k,:);
Vs = V1_all(k,:);            % water per tank (m^3)

Zq = 0:0.25:3;
nZ = numel(Zq);
tq = nan(1,nZ);
Vq = nan(1,nZ);

for i = 1:nZ
    if Zq(i) == 0
        idx = 1;
    else
        idx = find(Zs >= Zq(i), 1, 'first');
    end
    if ~isempty(idx)
        tq(i) = t(idx);
        Vq(i) = Vs(idx);
    end
end

Pz  = Patm + rho*g*Zq;
Pg0 = sigma*Pz;
Vc  = min(Vq, 0.999*Vtank);          % cap to avoid divide-by-zero at full tank
Pg  = Pg0.*Vtank./(Vtank - Vc);
dP  = Pg - Pz;
F   = dP*Avent*eta;
Treq = F*arm;

status = strings(1,nZ);
for i = 1:nZ
    if isnan(Treq(i))
        status(i) = "depth not reached";
    elseif Vq(i) >= Vtank
        status(i) = "tank full - not feasible";
    elseif Treq(i) <= Tmin
        status(i) = "OK";
    elseif Treq(i) <= Tmax
        status(i) = "marginal";
    else
        status(i) = "exceeds MG90S";
    end
end

Tvent = table(Zq', tq', Vq'*1e6, Pg0'/1e3, Pg'/1e3, Pz'/1e3, F', Treq', status', ...
    'VariableNames',{'Z_m','t_s','Vw_mL','Pg0_kPa','Pg_kPa','Pz_kPa','F_N','Torque_Nm','MG90S'});
fprintf('\n===== VENT VALVE FORCE & TORQUE (%.2f L/min per pump) =====\n',flow_sel);
disp(Tvent);

figure;
semilogy(Zq,Treq,'-o','LineWidth',1.5); hold on;
yline(Tmin,'r--','MG90S min = 0.176 N·m');
yline(Tmax,'g--','MG90S max = 0.216 N·m');
xlabel('Depth (m)'); ylabel('Required torque (N·m)');
title(sprintf('Vent valve torque vs depth (%.2f L/min per pump)',flow_sel));
grid on;

% Deepest depth where torque stays within MG90S lower limit
ok = Treq <= Tmin & ~isnan(Treq);
if any(ok)
    fprintf('Deepest depth within MG90S lower limit = %.2f m\n', max(Zq(ok)));
end