clc;
clear;
close all;

%% Parameters
g = 9.81;
rho = 1000;

md = 1.40;                 % Dry mass (kg)
Bmax = 17.74;              % Assumed full-submerged buoyancy (N)
Vdisp = Bmax/(rho*g);

Vtank = 250e-6;            % Capacity of each tank (m^3)
CD = 0.25;
D = 0.1;
A = pi*D^2/4;

zTarget = 1.2;             % Target depth (m)

%% Fixed pump flow rate
Q_Lmin = 0.90;             % Flow per pump (L/min)
Q = Q_Lmin*1e-3/60;        % Convert to m^3/s

%% Time settings
dt = 0.001;
tEnd = 40;
t = 0:dt:tEnd;
N = length(t);

z = zeros(1,N);
v = zeros(1,N);
V = zeros(1,N);

valveOpened = false;
tRelease = NaN;

%% Simulation
for n = 1:N-1

    % Fill both tanks equally until target depth
    if ~valveOpened
        V(n) = min(2*Q*t(n),2*Vtank);
    else
        V(n) = 0;
    end

    % Vehicle mass
    m = md + rho*V(n);

    % Fully submerged force model
    B = Bmax;
    Fdrag = 0.5*rho*CD*A*abs(v(n))*v(n);
    a = (m*g - B - Fdrag)/m;

    % Update velocity and depth
    v(n+1) = v(n) + a*dt;
    z(n+1) = z(n) + v(n+1)*dt;

    % Surface boundary
    if z(n+1) <= 0
        z(n+1) = 0;
        v(n+1) = 0;
    end

    % Instantaneous ballast release at target depth
    if ~valveOpened && z(n+1) >= zTarget
        valveOpened = true;
        V(n+1) = 0;
        tRelease = t(n+1);
    end
end

V(N) = V(N-1);

%% Plot 1: Total ballast volume vs time
figure;
plot(t,V*1e6,'LineWidth',1.8);
grid on;
xlabel('Time (s)');
ylabel('Total ballast volume (mL)');
title('Ballast Volume vs Time');
yline(500,'--k','Tank capacity');

%% Plot 2: Depth vs time
figure;
plot(t,z,'LineWidth',1.8);
grid on;
xlabel('Time (s)');
ylabel('Depth Z (m)');
title('Depth vs Time');
yline(zTarget,'--r','Target depth = 1.2 m');

%% Display result
fprintf('Pump flow rate per tank: %.2f L/min\n',Q_Lmin);
fprintf('Valve opening time: %.3f s\n',tRelease);