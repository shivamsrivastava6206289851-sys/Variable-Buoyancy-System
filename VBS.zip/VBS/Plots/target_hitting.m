clc;
clear;
close all;

%% =========================================================
% VBS AUTOMATIC 1.2 m STALL MODEL
%
% Phase 1:
%   Both pumps fill both ballast tanks.
%
% Phase 2:
%   At a mathematically calculated switching depth,
%   pumps OFF and both outlet servos open.
%
% Phase 3:
%   Water leaves -> mass decreases -> vehicle decelerates.
%
% Goal:
%   Find switching depth such that:
%
%             z = 1.2 m
%             v = 0 m/s
%
% at the first downward-to-upward velocity transition.
%
% ==========================================================

clc;
clear;
close all;

%% =========================================================
% 1. VEHICLE PARAMETERS
% ==========================================================

rho = 1000;                  % water density [kg/m^3]
g   = 9.81;                  % gravitational acceleration [m/s^2]

md = 1.40;                   % estimated dry mass [kg]

Bmax = 17.74;                % maximum buoyancy [N]

Cd = 0.25;                   % axial drag coefficient

% Vehicle frontal area
As = pi*(0.1)^2/4;           % [m^2]


%% =========================================================
% 2. BALLAST TANK PARAMETERS
% ==========================================================

Vtank = 250e-6;              % 250 mL per tank [m^3]

Vmax_total = 2*Vtank;        % 500 mL total

% Initial water in each tank
V1_initial = 0;
V2_initial = 0;


%% =========================================================
% 3. PUMP FLOW
% ==========================================================

% R385 pump assumed nominal flow
% IMPORTANT: this is a modelling assumption.

Qpump_Lmin = 0.90;           % L/min PER PUMP

Qpump = Qpump_Lmin*1e-3/60;  % m^3/s per pump


%% =========================================================
% 4. OUTLET VALVE / SERVO
% ==========================================================

% Equivalent full-open diameter
d_orifice = 3e-3;             % 3 mm

% Area of ONE outlet
Amax = pi*d_orifice^2/4;

% Servo angles to investigate
servoAngles = [15 30 45 60 75 90];


%% =========================================================
% 5. TARGET DEPTH
% ==========================================================

zTarget = 1.20;               % target depth [m]


%% =========================================================
% 6. GAS PRESSURE
% ==========================================================

Patm = 101325;                % atmospheric pressure [Pa]

% Paper uses 4.4 bar precharge in its 30 m model.
% Change this if your prototype uses a different precharge.

Pg0 = 4.4e5;                  % initial gas pressure [Pa]

% Each tank initially contains approximately 250 mL gas.
Vgas_initial = Vtank;


%% =========================================================
% 7. TIME STEP
% ==========================================================

dt = 0.001;                   % [s]

tEnd = 60;                    % maximum simulation time [s]

N = floor(tEnd/dt) + 1;


%% =========================================================
% 8. NEUTRAL BALLAST
% ==========================================================

% Fully submerged displaced volume
Vdisp = Bmax/(rho*g);

% Ballast required for neutral buoyancy
Vneutral = Vdisp - md/rho;

fprintf('\n--------------------------------------------\n');
fprintf('Neutral ballast = %.2f mL total\n', ...
        Vneutral*1e6);

fprintf('Neutral ballast per tank = %.2f mL\n', ...
        Vneutral*1e6/2);

fprintf('--------------------------------------------\n\n');


%% =========================================================
% 9. SEARCH RANGE FOR SWITCHING DEPTH
% ==========================================================

% We don't guess the final switching depth.
% MATLAB searches this interval.

switchDepth_min = 0.40;
switchDepth_max = 1.15;

switchDepth_step = 0.01;

switchDepths = switchDepth_min: ...
               switchDepth_step: ...
               switchDepth_max;


%% =========================================================
% 10. RESULT ARRAYS
% ==========================================================

bestSwitchDepth = zeros(size(servoAngles));
bestStopDepth   = zeros(size(servoAngles));
bestStopTime    = zeros(size(servoAngles));
bestError       = zeros(size(servoAngles));

bestResults = cell(length(servoAngles),1);


%% =========================================================
% 11. LOOP OVER SERVO ANGLES
% ==========================================================

for s = 1:length(servoAngles)

    theta = servoAngles(s);

    fprintf('\nServo angle = %d deg\n',theta);

    stopDepths = nan(size(switchDepths));
    stopTimes  = nan(size(switchDepths));


    %% =====================================================
    % SEARCH FOR BEST SWITCHING DEPTH
    % ======================================================

    for j = 1:length(switchDepths)

        zSwitch = switchDepths(j);

        [zStop,tStop,~,~,~] = ...
            simulateVBS(zSwitch,theta,...
                        rho,g,md,Bmax,Cd,As,...
                        Vtank,Qpump,...
                        Amax,Patm,Pg0,dt,tEnd);

        stopDepths(j) = zStop;
        stopTimes(j)  = tStop;

    end


    %% =====================================================
    % FIND SWITCH DEPTH CLOSEST TO 1.2 m
    % ======================================================

    valid = ~isnan(stopDepths);

    if any(valid)

        errorDepth = abs(stopDepths(valid) - zTarget);

        validSwitches = switchDepths(valid);
        validStops    = stopDepths(valid);
        validTimes    = stopTimes(valid);

        [minimumError,index] = min(errorDepth);

        bestSwitchDepth(s) = validSwitches(index);
        bestStopDepth(s)   = validStops(index);
        bestStopTime(s)    = validTimes(index);
        bestError(s)       = minimumError;

    else

        bestSwitchDepth(s) = NaN;
        bestStopDepth(s)   = NaN;
        bestStopTime(s)    = NaN;
        bestError(s)       = NaN;

    end


    %% =====================================================
    % RUN BEST CASE AGAIN FOR PLOTTING
    % ======================================================

    [zStop,tStop,t,z,v,V1,V2,Qout] = ...
        simulateVBS(bestSwitchDepth(s),theta,...
                    rho,g,md,Bmax,Cd,As,...
                    Vtank,Qpump,...
                    Amax,Patm,Pg0,dt,tEnd);

    bestResults{s}.t    = t;
    bestResults{s}.z    = z;
    bestResults{s}.v    = v;
    bestResults{s}.V1   = V1;
    bestResults{s}.V2   = V2;
    bestResults{s}.Qout = Qout;

    bestResults{s}.zStop = zStop;
    bestResults{s}.tStop = tStop;

end


%% =========================================================
% 12. PRINT RESULTS
% ==========================================================

fprintf('\n\n====================================================\n');
fprintf('        AUTOMATIC 1.2 m STALL RESULTS\n');
fprintf('====================================================\n');

fprintf('\n');

fprintf(' Servo     Switch Depth     Stop Depth      Error\n');
fprintf(' angle       [m]              [m]           [m]\n');
fprintf('----------------------------------------------------\n');

for s = 1:length(servoAngles)

    fprintf('%4d°       %7.3f          %7.3f       %7.3f\n',...
        servoAngles(s),...
        bestSwitchDepth(s),...
        bestStopDepth(s),...
        bestError(s));

end

fprintf('----------------------------------------------------\n');


%% =========================================================
% 13. DEPTH GRAPH
% ==========================================================

figure;

hold on;

for s = 1:length(servoAngles)

    plot(bestResults{s}.t,...
         bestResults{s}.z,...
         'LineWidth',1.5);

end

yline(zTarget,'k--',...
      '1.2 m target',...
      'LineWidth',1.5);

xlabel('Time [s]');
ylabel('Depth z [m]');

title('Depth Response with Automatically Calculated Valve Opening');

legend('15°','30°','45°','60°','75°','90°',...
       'Location','best');

grid on;


%% =========================================================
% 14. VELOCITY GRAPH
% ==========================================================

figure;

hold on;

for s = 1:length(servoAngles)

    plot(bestResults{s}.t,...
         bestResults{s}.v,...
         'LineWidth',1.5);

end

yline(0,'k--',...
      'v = 0',...
      'LineWidth',1.5);

xlabel('Time [s]');
ylabel('Vertical velocity [m/s]');

title('Velocity Response for 1.2 m Stall');

legend('15°','30°','45°','60°','75°','90°',...
       'Location','best');

grid on;


%% =========================================================
% 15. OUTLET FLOW RATE
% ==========================================================

figure;

hold on;

for s = 1:length(servoAngles)

    plot(bestResults{s}.t,...
         bestResults{s}.Qout*60*1000,...
         'LineWidth',1.5);

end

xlabel('Time [s]');
ylabel('Outlet flow rate [L/min]');

title('Outlet Flow Rate During 1.2 m Stall');

legend('15°','30°','45°','60°','75°','90°',...
       'Location','best');

grid on;


%% =========================================================
% 16. BALLAST VOLUME
% ==========================================================

figure;

hold on;

for s = 1:length(servoAngles)

    Vtotal = bestResults{s}.V1 + ...
             bestResults{s}.V2;

    plot(bestResults{s}.t,...
         Vtotal*1e6,...
         'LineWidth',1.5);

end

yline(Vneutral*1e6,...
      'k--',...
      'Neutral ballast',...
      'LineWidth',1.5);

xlabel('Time [s]');
ylabel('Total ballast water [mL]');

title('Ballast Volume During 1.2 m Stall');

legend('15°','30°','45°','60°','75°','90°',...
       'Location','best');

grid on;


%% =========================================================
% FUNCTION
% ==========================================================

function [zStop,tStop,t,z,v,V1,V2,Qout] = ...
    simulateVBS(zSwitch,theta,...
                rho,g,md,Bmax,Cd,As,...
                Vtank,Qpump,...
                Amax,Patm,Pg0,dt,tEnd)

    %% TIME

    t = 0:dt:tEnd;

    N = length(t);

    %% STATES

    z  = zeros(1,N);
    v  = zeros(1,N);

    V1 = zeros(1,N);
    V2 = zeros(1,N);

    Qout = zeros(1,N);

    %% CONTROL

    outletOpen = false;

    zStop = NaN;
    tStop = NaN;


    %% =====================================================
    % TIME LOOP
    % ======================================================

    for k = 1:N-1

        %% Current ballast

        Vtotal = V1(k) + V2(k);

        %% Current mass

        m = md + rho*Vtotal;


        %% =================================================
        % DETERMINE WHETHER FULLY SUBMERGED
        % =================================================

        Vdisp = Bmax/(rho*g);

        if m >= rho*Vdisp

            fullySubmerged = true;

        else

            fullySubmerged = false;

        end


        %% =================================================
        % PHASE 1: PUMP WATER IN
        % =================================================

        if ~outletOpen

            Qin1 = Qpump;
            Qin2 = Qpump;

            Qout_total = 0;

            %% Start outlet when target switching depth reached

            if fullySubmerged && z(k) >= zSwitch

                outletOpen = true;

                Qin1 = 0;
                Qin2 = 0;

            end


        %% =================================================
        % PHASE 2: OUTLET OPEN
        % =================================================

        else

            Qin1 = 0;
            Qin2 = 0;


            %% Ambient pressure

            Pz = Patm + rho*g*max(z(k),0);


            %% Gas volume in each tank

            Vgas1 = Vtank - V1(k);
            Vgas2 = Vtank - V2(k);

            Vgas1 = max(Vgas1,1e-9);
            Vgas2 = max(Vgas2,1e-9);


            %% Isothermal gas pressure

            Pg1 = Pg0*Vtank/Vgas1;
            Pg2 = Pg0*Vtank/Vgas2;


            %% Effective outlet area
            %
            % Linear first approximation:
            %
            % A(theta) = Amax*(theta/90)

            Aout = Amax*(theta/90);


            %% Tank 1 outflow

            DeltaP1 = Pg1 - Pz;

            if DeltaP1 > 0

                Q1out = Aout*sqrt(2*DeltaP1/rho);

            else

                Q1out = 0;

            end


            %% Tank 2 outflow

            DeltaP2 = Pg2 - Pz;

            if DeltaP2 > 0

                Q2out = Aout*sqrt(2*DeltaP2/rho);

            else

                Q2out = 0;

            end


            %% Total outflow

            Qout_total = Q1out + Q2out;

            Qout(k) = Qout_total;

        end


        %% =================================================
        % UPDATE TANK VOLUMES
        % =================================================

        V1(k+1) = V1(k) + ...
                  (Qin1-Qout_total/2)*dt;

        V2(k+1) = V2(k) + ...
                  (Qin2-Qout_total/2)*dt;


        %% Physical limits

        V1(k+1) = max(0,min(V1(k+1),Vtank));

        V2(k+1) = max(0,min(V2(k+1),Vtank));


        %% =================================================
        % NEW MASS
        % =================================================

        Vtotal = V1(k+1) + V2(k+1);

        m = md + rho*Vtotal;


        %% =================================================
        % BUOYANCY
        % =================================================

        if z(k) <= 1e-8 && m < rho*Vdisp

            % Floating at surface
            B = m*g;

        else

            % Fully submerged
            B = Bmax;

        end


        %% =================================================
        % WEIGHT
        % =================================================

        W = m*g;


        %% =================================================
        % DRAG
        % =================================================

        Fdrag = 0.5*rho*Cd*As*abs(v(k))*v(k);


        %% =================================================
        % VERTICAL ACCELERATION
        % =================================================

        a = (W-B-Fdrag)/m;


        %% =================================================
        % VELOCITY
        % =================================================

        v(k+1) = v(k) + a*dt;


        %% =================================================
        % DEPTH
        % =================================================

        z(k+1) = z(k) + v(k+1)*dt;


        %% =================================================
        % SURFACE CONDITION
        % =================================================

        if z(k+1) < 0

            z(k+1) = 0;

            if v(k+1) < 0

                v(k+1) = 0;

            end

        end


        %% =================================================
        % DETECT FIRST ZERO VELOCITY AFTER OUTLET OPENS
        % =================================================

        if outletOpen && ...
           k > 1 && ...
           v(k) > 0 && ...
           v(k+1) <= 0

            zStop = z(k+1);

            tStop = t(k+1);

            % Stop simulation once first turning point occurs
            return;

        end

    end

end