
clc;
clear;
close all;

%% 1. VBS PARAMETERS
rho = 1000;                 % Water density (kg/m^3)
g = 9.81;                   % Gravitational acceleration (m/s^2)

md = 1.189;                 % Dry mass (kg)
Bmax = 15.06;               % Estimated maximum buoyancy (N)

% External displaced volume estimated from buoyancy
Vdisp = Bmax/(rho*g);

% Two ballast tanks
N_tanks = 2;
Vtank = 250e-6;              % Capacity per tank (m^3) = 250 mL
Vmax = N_tanks*Vtank;        % Total capacity = 500 mL

%% 2. DRAG PARAMETERS
CD = 0.25;                   % Assumed axial drag coefficient
D = 0.10;                    % Assumed vehicle diameter (m)
A = pi*D^2/4;                % Frontal area (m^2)

%% 3. PUMP FLOW RATES
% Flow rate of EACH pump
flow_Lmin = [0.45 0.90 1.35 1.80];

% Convert L/min to m^3/s
Qpump = flow_Lmin*1e-3/60;

%% 4. SIMULATION SETTINGS
dt = 0.01;                   % Time step (s)
tEnd = 40;                   % Simulation duration (s)
t = 0:dt:tEnd;
N = length(t);

nCases = length(Qpump);

% Initialize output arrays
Z_all = zeros(nCases,N);
V1_all = zeros(nCases,N);
V2_all = zeros(nCases,N);
Vtotal_all = zeros(nCases,N);
Mass_all = zeros(nCases,N);
Weight_all = zeros(nCases,N);
Velocity_all = zeros(nCases,N);

%% 5. SIMULATION FOR EACH PUMP FLOW RATE
for k = 1:nCases

    % Initial conditions
    z = zeros(1,N);           % Depth (m), positive downward
    v = zeros(1,N);           % Vertical velocity (m/s)

    V1 = zeros(1,N);          % Tank 1 water volume (m^3)
    V2 = zeros(1,N);          % Tank 2 water volume (m^3)
    Vtotal = zeros(1,N);      % Total water volume (m^3)
    mass = zeros(1,N);        % Total vehicle mass (kg)
    weight = zeros(1,N);      % Total weight (N)

    for n = 1:N-1

        %% 5A. WATER VOLUME IN EACH TANK
        % Both pumps run at the same constant flow rate.
        V1(n) = min(Qpump(k)*t(n),Vtank);
        V2(n) = min(Qpump(k)*t(n),Vtank);

        % Total ballast volume
        Vtotal(n) = V1(n) + V2(n);

        %% 5B. UPDATE TOTAL MASS AND WEIGHT
        mass(n) = md + rho*Vtotal(n);
        weight(n) = mass(n)*g;

        %% 5C. BUOYANCY MODEL
        % Simplified partial-submergence approximation:
        % before full-submergence mass threshold, B = weight.
        % Once fully submerged, buoyancy is constant at Bmax.
        if mass(n)*g < Bmax
            B = weight(n);
        else
            B = Bmax;
        end

        %% 5D. DRAG FORCE
        % Positive velocity means downward motion.
        Fdrag = 0.5*rho*CD*A*abs(v(n))*v(n);

        %% 5E. VERTICAL EQUATION OF MOTION
        % m*a = Weight - Buoyancy - Drag
        a = (weight(n) - B - Fdrag)/mass(n);

        %% 5F. NUMERICAL INTEGRATION
        v(n+1) = v(n) + a*dt;
        z(n+1) = z(n) + v(n+1)*dt;

        %% 5G. SURFACE LIMIT
        if z(n+1) < 0
            z(n+1) = 0;

            if v(n+1) < 0
                v(n+1) = 0;
            end
        end
    end

    %% 6. CALCULATE FINAL TIME-STEP VALUES
    V1(N) = min(Qpump(k)*t(N),Vtank);
    V2(N) = min(Qpump(k)*t(N),Vtank);
    Vtotal(N) = V1(N) + V2(N);

    mass(N) = md + rho*Vtotal(N);
    weight(N) = mass(N)*g;

    %% 7. SAVE RESULTS
    Z_all(k,:) = z;
    V1_all(k,:) = V1;
    V2_all(k,:) = V2;
    Vtotal_all(k,:) = Vtotal;
    Mass_all(k,:) = mass;
    Weight_all(k,:) = weight;
    Velocity_all(k,:) = v;
end

%% 8. PLOT: DEPTH VS TIME
figure;
hold on;

for k = 1:nCases
    plot(t,Z_all(k,:),'LineWidth',1.5,...
        'DisplayName',sprintf('%.2f L/min per pump',flow_Lmin(k)));
end

xlabel('Time (s)');
ylabel('Depth (m)');
title('VBS: Depth vs Time');
legend('Location','best');
grid on;

%% 9. PLOT: TOTAL BALLAST VOLUME VS TIME
figure;
hold on;

for k = 1:nCases
    plot(t,Vtotal_all(k,:)*1e6,'LineWidth',1.5,...
        'DisplayName',sprintf('%.2f L/min per pump',flow_Lmin(k)));
end

yline(Vmax*1e6,'k--','Total capacity = 500 mL');
xlabel('Time (s)');
ylabel('Total ballast volume (mL)');
title('VBS: Total Ballast Volume vs Time');
legend('Location','best');
grid on;

%% 10. PLOT: TOTAL BALLAST VOLUME VS DEPTH
figure;
hold on;

for k = 1:nCases
    plot(Z_all(k,:),Vtotal_all(k,:)*1e6,'LineWidth',1.5,...
        'DisplayName',sprintf('%.2f L/min per pump',flow_Lmin(k)));
end

xlabel('Depth (m)');
ylabel('Total ballast volume (mL)');
title('VBS: Total Ballast Volume vs Depth');
legend('Location','best');
grid on;

%% 11. PLOT: TOTAL MASS VS TIME
figure;
hold on;

for k = 1:nCases
    plot(t,Mass_all(k,:),'LineWidth',1.5,...
        'DisplayName',sprintf('%.2f L/min per pump',flow_Lmin(k)));
end

yline(md,'k--','Dry mass = 1.189 kg');
yline(md + rho*Vmax,'r--','Full-ballast mass = 1.689 kg');

xlabel('Time (s)');
ylabel('Total mass (kg)');
title('VBS: Total Mass vs Time');
legend('Location','best');
grid on;

%% 12. PLOT: VELOCITY VS TIME
figure;
hold on;

for k = 1:nCases
    plot(t,Velocity_all(k,:),'LineWidth',1.5,...
        'DisplayName',sprintf('%.2f L/min per pump',flow_Lmin(k)));
end

xlabel('Time (s)');
ylabel('Vertical velocity (m/s)');
title('VBS: Velocity vs Time');
legend('Location','best');
grid on;

%% 13. DISPLAY FINAL CALCULATIONS
mFull = md + rho*Vmax;
Wdry = md*g;
Wfull = mFull*g;
FnetFull = Wfull - Bmax;

fprintf('\n===== TWO-TANK VBS RESULTS =====\n');
fprintf('Dry mass                  = %.3f kg\n',md);
fprintf('Dry weight                = %.2f N\n',Wdry);
fprintf('Maximum buoyancy          = %.2f N\n',Bmax);
fprintf('Estimated displaced volume= %.3f L\n',Vdisp*1000);
fprintf('Tank capacity per tank    = %.0f mL\n',Vtank*1e6);
fprintf('Total ballast capacity    = %.0f mL\n',Vmax*1e6);
fprintf('Fully ballasted mass      = %.3f kg\n',mFull);
fprintf('Fully ballasted weight    = %.2f N\n',Wfull);
fprintf('Net force at full ballast = %.2f N downward\n',FnetFull);

% Neutral ballast volume under the assumed constant buoyancy
Vneutral = (Bmax/g - md)/rho;

fprintf('Neutral ballast estimate  = %.1f mL\n',Vneutral*1e6);
