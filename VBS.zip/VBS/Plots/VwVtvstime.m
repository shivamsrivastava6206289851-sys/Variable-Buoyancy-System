clc
clear
close all

%% PARAMETERS
Pg0  = 4.4e5;           % Pa
Patm = 101325;          % Pa
rho  = 1025;            % kg/m^3
g    = 9.81;
Z    = 30;

Pa = Patm + rho*g*Z;

eta = 0.4;

At = 4.8e-3;            % m^2

Vt = [0.5e-3 1e-3];

kappa = 5e-5:5e-5:3e-4;

figure
hold on
grid on
box on

for j = 1:length(Vt)

    for i = 1:length(kappa)

        k = kappa(i);

        ode = @(t,x) ...
            -(k*At/Vt(j))*sqrt( ...
            (2*eta/(rho*(1-k^2)))* ...
            max(Pg0./(1-x)-Pa,0));

        opts = odeset('Events',@stopFcn,...
                      'RelTol',1e-8,...
                      'AbsTol',1e-10);

        % Adaptive solution
        [t,x] = ode45(ode,[0 90],0.8,opts);

        if j==1

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % 0.5 L : Red solid line
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            plot(t,x,'r-','LineWidth',2);

        else

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % 1.0 L : Black dashed line
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            plot(t,x,'k--','LineWidth',2);

            % Marker locations every 7 s
            tmark = 0:7:t(end);

            % Interpolate solution
            xmark = interp1(t,x,tmark);

            % Plot filled diamonds
            plot(tmark,xmark,'kd',...
                'MarkerFaceColor','k',...
                'MarkerEdgeColor','k',...
                'MarkerSize',8);

            % Ensure final point is always marked
            plot(t(end),x(end),'kd',...
                'MarkerFaceColor','k',...
                'MarkerEdgeColor','k',...
                'MarkerSize',8);

        end

    end

end

xlabel('Time (s)','FontSize',13)
ylabel('V_w/V_t','FontSize',13)

xlim([0 90])
ylim([0 0.82])

legend('0.5 L','1.0 L','Location','northeast')

set(gca,'FontSize',12,'LineWidth',1.5)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [value,isterminal,direction] = stopFcn(~,x)

value = x;          % Stop when x = 0
isterminal = 1;
direction = -1;

end